package util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.*;
import conn.connGaussdb;

public class detail_essay {
	public essay search_eid(int eid)throws Exception{
		//connGaussdb connG=new connGaussdb();
		
		Connection conn=connGaussdb.getConn();
		Statement stmt=null;
		String sql=null;
		ResultSet rs=null;
		essay e=new essay();
	//	ArrayList<essay> ess=new ArrayList();
		try{
			stmt=(Statement)conn.createStatement(); //����statement������
		
				sql="select * from essay where eid="+eid ;
			
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
			//	essay e=new essay();
				e.setEid(rs.getInt("eid"));
				e.setTitle(rs.getString("title"));
				e.setAuthor(rs.getString("author"));
				e.setOrgan(rs.getString("organ"));
				e.setSummary(rs.getString("summary"));
			      
			}
		}catch(SQLException m) {
			System.out.println("ʵ����ʧ��");
			m.printStackTrace();
		}finally {
			connGaussdb.close(conn, stmt, rs);
		}
		return e;
	}
	
	public publish search_publish(int eid)throws Exception{
		Connection conn=connGaussdb.getConn();
		Statement stmt=null;
		String sql=null;
		ResultSet rs=null;
		publish p=new publish();
	
		try{
			stmt=(Statement)conn.createStatement(); //����statement������
				sql="select * from publish where eid="+eid ;
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				
				p.setPubTime(rs.getString("pubTime"));
				p.setVolume(rs.getString("volume"));
				p.setPeriod(rs.getString("period"));
				p.setPageCount(rs.getString("pageCount"));
				p.setCited(rs.getInt("cited"));
				p.setDownloaded(rs.getInt("downloaded"));
			     System.out.println(rs.getString("period"));
			}
		}catch(SQLException m) {
			System.out.println("ʵ����ʧ��");
			m.printStackTrace();
		}finally {
			connGaussdb.close(conn, stmt, rs);
		}
		return p;
	}
	
	public source search_source(int eid)throws Exception{
		Connection conn=connGaussdb.getConn();
		Statement stmt=null;
		String sql=null;
		ResultSet rs=null;
		source s=new source();
	
		try{
			stmt=(Statement)conn.createStatement(); //����statement������
				sql="select * from source "
						+ "where sid in(select sid from publish where eid="+eid+")";
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				s.setName(rs.getString("name"));
				s.setPlace(rs.getString("place"));
				s.setUrl(rs.getString("url"));
				s.setTel(rs.getString("tel"));				   
			}
		}catch(SQLException m) {
			System.out.println("ʵ����ʧ��");
			m.printStackTrace();
		}finally {
			connGaussdb.close(conn, stmt, rs);
		}
		return s;
	}
	public minority search_minority(int eid) throws Exception{
		Connection conn=connGaussdb.getConn();
		Statement stmt=null;
		String sql=null;
		ResultSet rs=null;
		minority m=new minority();
		try{
			stmt=(Statement)conn.createStatement(); //����statement������
				sql="select * from minority "
						+ "where mid=(select mid from essay where eid="+eid+")";
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				m.setName(rs.getString("name"));
				m.setInfo(rs.getString("info"));
				m.setMid(rs.getInt("mid"));			   
			}
		}catch(SQLException e) {
			System.out.println("ʵ����ʧ��");
			e.printStackTrace();
		}finally {
			connGaussdb.close(conn, stmt, rs);
		}
		return m;
	}
}
