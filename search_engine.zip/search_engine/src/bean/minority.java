package bean;

public class minority {
	private int mid;
	private String name;
	private String info;
	
	public void setMid(int mid){
		this.mid=mid;
	}
	public int getMid() {
		return mid;
	}
	
	public void  setName(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	
	public void  setInfo(String info) {
		this.info=info;
	}
	public String getInfo() {
		return info;
	}
}
