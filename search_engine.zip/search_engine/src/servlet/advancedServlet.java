package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class advancedServlet
 * ��searchResult.jsp�и߼�������Ĳ������浽session����searchResult.jspҳ�����
 */
@WebServlet("/searchResult/advancedServlet")
public class advancedServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public advancedServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");  //��ֹ��������Ĳ�����������
	    response.setContentType("text/html;charset=UTF-8");
	    request.getSession().getAttribute("testSession");
	    
	    String time_horizon=request.getParameter("time_horizon"); //�õ���searchResult.jsp �߼���������Ĳ���
	    String source=request.getParameter("source");
	    String minority=request.getParameter("minority");
	    
	    if(!time_horizon.equals("")||!source.contentEquals("")||!minority.contentEquals("")) {
	    	HttpSession session=request.getSession();
	    	session.setAttribute("time_horizon", time_horizon); //��ҳ�洫��Ĳ������浽session��
	    	session.setAttribute("source", source);
	    	session.setAttribute("minority", minority);
	 
	    	request.setAttribute("selectState", "searchResult.jsp");
	    	ServletContext application = getServletContext();
            RequestDispatcher rd = request.getRequestDispatcher("/searchResult/searchResult.jsp");
            rd.forward(request, response); //��������ת��searchResult.jspҳ��
	    }
	}

}
